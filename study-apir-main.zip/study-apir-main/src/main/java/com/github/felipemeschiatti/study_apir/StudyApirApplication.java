package com.github.felipemeschiatti.study_apir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyApirApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyApirApplication.class, args);
	}

}
