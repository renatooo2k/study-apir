package com.github.felipemeschiatti.study_apir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyApirApplicationTests {

	@Test
	void contextLoads() {
	}

}
